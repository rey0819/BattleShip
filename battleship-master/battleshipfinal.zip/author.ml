(* TODO: set the value below *)
let hours_worked = [23;23;23]
