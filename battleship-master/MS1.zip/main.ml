(* Print empty board then play loop? *)

(* IF USER PUTS IN INVALID STUFF IT WON'T WORK *)
let rec ship_parse_helper lst = 
  match lst with 
  | h::t -> (String.get (String.sub h 0 1) 0 , int_of_string(String.sub h 1 (String.length h-1 )))::ship_parse_helper t
  | _ -> []

let ship_parse lst =
  let place_list = ship_parse_helper lst in 
  (List.hd place_list, List.hd (List.tl place_list))


let rec play_loop st =
  let enemy_board = State.enemy_board st in 
  let player_board = State.player_board st in 
  Board.print_board player_board enemy_board;
  let () = print_string "\nType your command: " in
  let i = read_line () in
  try let com = Command.parse i in
    match com with
    | Quit -> ANSITerminal.(print_string [cyan] "Thanks for playing!\n"); 
      exit 0
    | Place t -> begin match 
          let places = ship_parse t in 
          (State.place places st) with 
      | Legal t -> play_loop t
      | Illegal -> ANSITerminal.(print_string [yellow] "Invalid ship placement \n"); 
        play_loop st
      end
    | _ -> play_loop st
  with 
  |Command.Malformed -> 
    ANSITerminal.(print_string [cyan] "Please type a valid command\n"); 
    play_loop st 
  | Command.Empty -> 
    ANSITerminal.(print_string [cyan] "Please type a command\n"); 
    play_loop st
  | Failure _ -> ANSITerminal.(print_string [cyan] "Invalid Ship placement spot \n"); 
    play_loop st



(** [main ()] prompts for the game to play, then starts it. *)
let main () =
  ANSITerminal.(print_string [red] "Welcome to Battleship! \n \n");
  let state = State.init_state in
  play_loop state

let () = main ()
