type t = {
  enemy : Board.t;
  mine : Board.t;

}

type result = Legal of t | Illegal

let init_state =
  {
    enemy = Board.empty_guess_board;
    mine = Board.empty_ship_board;
  }

let enemy_board st =
  st.enemy

let player_board st =
  st.mine







(* -----------Place functions---------------------- *)


(** [list_helper_chr chr range start] creates the position list if the ship
    is vertical *)
let rec list_helper_chr num range start= 
  if range > 0 
  then (Char.chr (range + start - 1), num)::list_helper_chr num (range - 1) start
  else [] 

(** [list_helper_int chr range start] creates the position list if the ship
    is horizontal *)
let rec list_helper_int (chr:char) range start= 
  if range > 0 
  then (chr, range+start - 1)::list_helper_int chr (range - 1) start
  else []

(** [pair_to_list pair] is a list of (char*int) that is the list of 
    positions between the positions in [pair]*)
let pair_to_list pair =
  let chr1 = fst (fst pair) in 
  let chr2 = fst (snd pair) in 
  let num1 = snd (fst pair) in 
  let num2 = snd (snd pair) in
  if (chr1 = chr2) 
  then list_helper_int chr1 (num2 - num1 + 1) num1
  else let chr_range = ((Char.code chr2) - (Char.code chr1) + 1) in 
    list_helper_chr num1 chr_range (Char.code chr1)

(** [place_helper lst brd] places all ships in [lst] onto ship board [brd]*)
let rec place_helper lst brd =
  match lst with 
  | h::t -> place_helper t (Board.place_ship brd h (List.length lst))
  | [] -> brd


(* TODO: Still need illegal, right not everything is being caught in main. 
   We are not even using check_placement in board. *)
let place ship_places st =
  let list1 = pair_to_list ship_places in 
  if Board.check_placement st.mine (List.length list1) ship_places list1 then
    let m_temp = place_helper (pair_to_list ship_places) st.mine in 
    Legal {
      enemy = st.enemy;
      mine = Board.set_length_list m_temp (List.length list1) 
    }
  else
    Illegal
